import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BMICalculator extends JFrame {

    private JTextField weightField;
    private JTextField heightField;
    private JLabel bmiResultLabel;
    private JLabel categoryLabel;

    public BMICalculator() {
        setTitle("BMI Calculator");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel("BMI CALCULATOR", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));

        // Input fields
        JLabel weightLabel = new JLabel("Weight (kg):");
        weightField = new JTextField();

        JLabel heightLabel = new JLabel("Height (m):");
        heightField = new JTextField();

        // Buttons
        JButton calculateButton = new JButton("Calculate BMI");
        JButton clearButton = new JButton("Clear");

        // Results
        bmiResultLabel = new JLabel("BMI: ");
        categoryLabel = new JLabel("Category: ");

        bmiResultLabel.setFont(new Font("Arial", Font.BOLD, 16));
        categoryLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Add title
        add(titleLabel, BorderLayout.NORTH);

        // Add components to panel
        panel.add(weightLabel);
        panel.add(weightField);

        panel.add(heightLabel);
        panel.add(heightField);

        panel.add(calculateButton);
        panel.add(clearButton);

        panel.add(bmiResultLabel);
        panel.add(categoryLabel);

        // Extra empty cells
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));

        add(panel, BorderLayout.CENTER);

        // Calculate button action
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateBMI();
            }
        });

        // Clear button action
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
    }

    private void calculateBMI() {
        try {
            double weight = Double.parseDouble(weightField.getText());
            double height = Double.parseDouble(heightField.getText());

            if (weight <= 0 || height <= 0) {
                JOptionPane.showMessageDialog(
                    this,
                    "Weight and height must be greater than zero.",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            // BMI formula
            double bmi = weight / (height * height);

            // Determine BMI category
            String category;

            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi < 25.0) {
                category = "Normal";
            } else if (bmi < 30.0) {
                category = "Overweight";
            } else {
                category = "Obese";
            }

            // Display result
            bmiResultLabel.setText(String.format("BMI: %.2f", bmi));
            categoryLabel.setText("Category: " + category);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Please enter valid numbers for weight and height.",
                "Invalid Input",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void clearFields() {
        weightField.setText("");
        heightField.setText("");
        bmiResultLabel.setText("BMI: ");
        categoryLabel.setText("Category: ");
        weightField.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BMICalculator().setVisible(true);
            }
        });
    }
}

